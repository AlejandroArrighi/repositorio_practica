def funcion_modulo2():
    print("Hola, soy un modulo en el paquete modulo2")