def funcionPaquete():
    print("Hola estoy en mi paquete")